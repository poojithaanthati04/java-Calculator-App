import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner sc = new Scanner(System.in);

        int number = random.nextInt(100) + 1;
        int guess, attempts = 0;

        System.out.println("Guess a number between 1 and 100");

        do {
            System.out.print("Enter guess: ");
            guess = sc.nextInt();
            attempts++;

            if(guess < number)
                System.out.println("Too low");
            else if(guess > number)
                System.out.println("Too high");
            else
                System.out.println("Correct! Attempts: " + attempts);

        } while(guess != number);

        sc.close();
    }
}