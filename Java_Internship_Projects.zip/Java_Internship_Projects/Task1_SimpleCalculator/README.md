
# Java Internship Projects

## How to Run
1. Open terminal inside project folder
2. Compile:
   javac Main.java

3. Run:
   java Main
