import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        HashMap<String, String> users = new HashMap<>();
        users.put("admin", "1234");

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        if(users.containsKey(username) && users.get(username).equals(password)) {
            System.out.println("Login successful");
        } else {
            System.out.println("Invalid credentials");
        }

        sc.close();
    }
}