import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Simple Notepad");
        JTextArea textArea = new JTextArea();

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");

        JMenuItem openItem = new JMenuItem("Open");
        JMenuItem saveItem = new JMenuItem("Save");

        openItem.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            int option = chooser.showOpenDialog(frame);

            if(option == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();

                try(BufferedReader br = new BufferedReader(new FileReader(file))) {
                    textArea.read(br, null);
                } catch(Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        saveItem.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            int option = chooser.showSaveDialog(frame);

            if(option == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();

                try(BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
                    textArea.write(bw);
                } catch(Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        menuBar.add(fileMenu);

        frame.setJMenuBar(menuBar);
        frame.add(new JScrollPane(textArea));

        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}