import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

        while(true) {
            Date date = new Date();
            System.out.print("\rCurrent Time: " + sdf.format(date));
            Thread.sleep(1000);
        }
    }
}